export function getTriangle() {
    return [
        -0.5, -0.5, 0,
        0.0, 0.5, 0,
        0.5, -0.5, 0
    ]
}